 if (context.flow=="TARGET_REQ_FLOW") {
   
   
    var proxy_pathSuffix = context.getVariable("proxy.pathsuffix");
    var target = context.getVariable('target.url');

    
    context.setVariable("target.url", target);
}