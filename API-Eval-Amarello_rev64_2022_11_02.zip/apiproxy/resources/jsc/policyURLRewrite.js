 if (context.flow=="TARGET_REQ_FLOW") {
   
    var newPathSuffix = context.getVariable("idTargetPathSuffix");
    
    var proxy_pathSuffix = context.getVariable("proxy.pathsuffix");

    var req_querystring = context.getVariable("request.querystring");
    var target = context.getVariable('target.url');

    var new_target_pathsuffix = newPathSuffix + req_querystring;
    
    var urlParts = proxy_pathSuffix.split("/");
    var id = "/" + urlParts[urlParts.length - 1];
    new_target_pathsuffix = newPathSuffix + id + req_querystring;
    

    context.setVariable("target.url", target + new_target_pathsuffix);
}