 if (context.flow=="TARGET_REQ_FLOW") {
   
    var newPathSuffix = context.getVariable("asignacionID");
    
    var proxy_pathSuffix = context.getVariable("proxy.pathsuffix");

    var target = context.getVariable('target.url');

   var new_target_pathsuffix = "/" + newPathSuffix;
    
    context.setVariable("target.url", target + new_target_pathsuffix);
}